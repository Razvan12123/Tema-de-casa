#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

// Function to calculate the Levenshtein distance
int levenshtein_distance(const char *s1, const char *s2) {
    int len1 = strlen(s1);
    int len2 = strlen(s2);
    int i, j;

    // Allocate memory for the distance matrix
    int **dist = (int **)malloc((len1 + 1) * sizeof(int *));
    for (i = 0; i <= len1; i++) {
        dist[i] = (int *)malloc((len2 + 1) * sizeof(int));
    }

    // Initialize the distance matrix
    for (i = 0; i <= len1; i++) {
        dist[i][0] = i;
    }
    for (j = 0; j <= len2; j++) {
        dist[0][j] = j;
    }

    // Compute the distances
    for (i = 1; i <= len1; i++) {
        for (j = 1; j <= len2; j++) {
            int cost = (s1[i - 1] == s2[j - 1]) ? 0 : 1;
            dist[i][j] = fmin(fmin(dist[i - 1][j] + 1, dist[i][j - 1] + 1), dist[i - 1][j - 1] + cost);
        }
    }

    int distance = dist[len1][len2];

    // Free the memory allocated for the distance matrix
    for (i = 0; i <= len1; i++) {
        free(dist[i]);
    }
    free(dist);

    return distance;
}

// Function to generate random strings
void generate_random_string(char *str, int length) {
    static const char charset[] = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";
    for (int i = 0; i < length; i++) {
        int key = rand() % (int)(sizeof(charset) - 1);
        str[i] = charset[key];
    }
    str[length] = '\0';
}

// Function to test the Levenshtein distance function with large input data
void test_large_input() {
    // Lengths of the strings
    int lengths[] = {1000, 10000, 100000, 1000000, 10000000};
    int num_tests = sizeof(lengths) / sizeof(lengths[0]);

    // Generate and test strings of increasing length
    for (int i = 0; i < num_tests; i++) {
        int len = lengths[i];
        char *s1 = (char *)malloc((len + 1) * sizeof(char));
        char *s2 = (char *)malloc((len + 1) * sizeof(char));

        generate_random_string(s1, len);
        generate_random_string(s2, len);

        clock_t start = clock();
        int distance = levenshtein_distance(s1, s2);
        clock_t end = clock();

        double time_spent = (double)(end - start) / CLOCKS_PER_SEC;
        printf("Length: %d, Levenshtein Distance: %d, Time Spent: %f seconds\n", len, distance, time_spent);

        free(s1);
        free(s2);
    }
}

int main() {
    srand(time(NULL));
    test_large_input();
    return 0;
}
 //https://github.com/Razvan12123/Tema-de-casa
